# SupplyChainX Project Summary

## Dataset
- Records: 26,960
- SKUs: 40
- Test period: 60 days

## Model
Random Forest Regressor with chronological train/test evaluation.

## Results
- MAE: 5.0614
- RMSE: 6.6707
- R²: 0.943

The dataset is synthetic and intended for portfolio/educational use.
